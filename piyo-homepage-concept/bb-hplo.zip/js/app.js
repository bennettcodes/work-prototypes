window.onload = function () {

    hpFpo.imagesLoaded(function() {
        style();
        generalFunctions();
    });

};
